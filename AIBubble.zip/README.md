# AI Bubble (test build 0.1)

Android launcher + floating AI heads + MCP relay.

1. Push this folder to a GitHub repo. Actions builds the APK (Actions tab > Build APK > artifact).
2. Add repo secrets CLOUDFLARE_API_TOKEN and CLOUDFLARE_ACCOUNT_ID. Pushing relay/ (or running "Deploy relay") deploys the Worker.
3. Install the APK, paste the Worker URL, copy the MCP URL into your AI app as a custom connector (no authentication).
4. Turn on the AI Bubble accessibility service.
