# AI Bubble 0.3

Android launcher + floating AI heads + two session buttons + MCP relay.

## Update steps
1. Replace AIBubble.zip in the repo root with this one (same file name), commit to main.
2. Actions tab > Build and deploy > Run workflow. Both jobs must pass (apk, relay).
3. Download the aibubble-debug-apk artifact and install it.

## What is new in 0.3
- Screen button (ayin) and voice button (pe) under the heads/bubble. Pressed in + colored = on.
- Screen session: Android capture prompt; read_screen, highlight and take_screenshot work only while it is on.
  Auto-stops on sensitive apps, a blank/protected screen, or phone lock.
- Voice session: speak_text and get_speech_transcript tools. Hold the voice button (while on) to talk now.
- Drag any head to the X at the bottom to close everything.
- Quick Settings tiles: "AI screen" and "AI voice".
- Heads row stays transparent. Tap the active head to minimize to one bubble.

## Tools exposed by the relay
session_status, read_screen, take_screenshot, highlight, clear_highlight, speak_text, get_speech_transcript
