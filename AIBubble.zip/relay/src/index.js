const TOOLS = [
  {
    name: "read_screen",
    description: "Read the phone's current screen: visible text, clickable elements and their pixel bounds, plus screen size.",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "highlight",
    description: "Draw a highlight box on the phone screen for about 8 seconds. Give either 'text' (visible label to find) or x, y, width, height in pixels.",
    inputSchema: {
      type: "object",
      properties: {
        text: { type: "string" },
        x: { type: "number" },
        y: { type: "number" },
        width: { type: "number" },
        height: { type: "number" },
      },
    },
  },
  {
    name: "clear_highlight",
    description: "Remove the highlight from the phone screen.",
    inputSchema: { type: "object", properties: {} },
  },
];

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const m = url.pathname.match(/^\/t\/([A-Za-z0-9]{32,})\/(mcp|poll|result|clients)$/);
    if (!m) return new Response("not found", { status: 404 });
    const stub = env.HUB.get(env.HUB.idFromName(m[1]));
    const u = new URL(request.url);
    u.pathname = "/" + m[2];
    return stub.fetch(new Request(u, request));
  },
};

export class Hub {
  constructor(state) {
    this.state = state;
    this.queue = [];
    this.waiter = null;
    this.pending = new Map();
  }

  async fetch(request) {
    const path = new URL(request.url).pathname;
    if (path === "/mcp") return this.mcp(request);
    if (path === "/poll") return this.poll();
    if (path === "/result") {
      const b = await request.json();
      const done = this.pending.get(b.id);
      if (done) {
        this.pending.delete(b.id);
        done(String(b.result));
      }
      return new Response("ok");
    }
    if (path === "/clients") {
      return Response.json((await this.state.storage.get("clients")) || {});
    }
    return new Response("not found", { status: 404 });
  }

  send(cmd) {
    if (this.waiter) {
      const w = this.waiter;
      this.waiter = null;
      w(cmd);
    } else {
      this.queue.push(cmd);
    }
  }

  async poll() {
    if (this.queue.length) return Response.json(this.queue.shift());
    const cmd = await new Promise((res) => {
      this.waiter = res;
      setTimeout(() => {
        if (this.waiter === res) {
          this.waiter = null;
          res(null);
        }
      }, 20000);
    });
    return cmd ? Response.json(cmd) : new Response(null, { status: 204 });
  }

  async mcp(request) {
    if (request.method !== "POST") return new Response("POST only", { status: 405 });
    const msg = await request.json();
    const { id, method, params } = msg;
    if (id === undefined) return new Response(null, { status: 202 });
    const reply = (result) => Response.json({ jsonrpc: "2.0", id, result });

    switch (method) {
      case "initialize": {
        const ci = (params && params.clientInfo) || {};
        const name = ci.name || "unknown";
        const clients = (await this.state.storage.get("clients")) || {};
        clients[name] = { name, version: ci.version || "", last: Date.now() };
        await this.state.storage.put("clients", clients);
        return reply({
          protocolVersion: (params && params.protocolVersion) || "2025-03-26",
          capabilities: { tools: {} },
          serverInfo: { name: "ai-bubble", version: "0.1.0" },
        });
      }
      case "ping":
        return reply({});
      case "tools/list":
        return reply({ tools: TOOLS });
      case "tools/call": {
        const cid = crypto.randomUUID();
        const text = await new Promise((res) => {
          this.pending.set(cid, res);
          this.send({ id: cid, tool: params.name, args: params.arguments || {} });
          setTimeout(() => {
            if (this.pending.delete(cid)) {
              res("timeout: the phone did not answer. Is the AI Bubble accessibility service on?");
            }
          }, 25000);
        });
        return reply({ content: [{ type: "text", text }] });
      }
      default:
        return Response.json({ jsonrpc: "2.0", id, error: { code: -32601, message: "Method not found" } });
    }
  }
}
