const NO_ARGS = { type: "object", properties: {} };

const TOOLS = [
  {
    name: "session_status",
    description: "Check whether the user's screen session and voice session are on. Call this first. The user controls both with buttons on their phone.",
    inputSchema: NO_ARGS,
  },
  {
    name: "read_screen",
    description: "Read the phone's current screen: visible text, clickable elements and their pixel bounds, plus screen size. Only works while the user's screen session is on.",
    inputSchema: NO_ARGS,
  },
  {
    name: "take_screenshot",
    description: "Capture a reduced-size screenshot of the phone screen. Use it for games and apps with no readable text. Only works while the user's screen session is on.",
    inputSchema: NO_ARGS,
  },
  {
    name: "highlight",
    description: "Draw a highlight box on the phone screen for about 8 seconds. Give either 'text' (visible label to find) or x, y, width, height in pixels. Only works while the screen session is on.",
    inputSchema: {
      type: "object",
      properties: {
        text: { type: "string" },
        x: { type: "number" },
        y: { type: "number" },
        width: { type: "number" },
        height: { type: "number" },
      },
    },
  },
  {
    name: "clear_highlight",
    description: "Remove the highlight from the phone screen.",
    inputSchema: NO_ARGS,
  },
  {
    name: "speak_text",
    description: "Say a short message aloud on the user's phone. Only works while the user's voice session is on.",
    inputSchema: {
      type: "object",
      properties: { text: { type: "string" } },
      required: ["text"],
    },
  },
  {
    name: "get_speech_transcript",
    description: "Get what the user said. Give wait_seconds (max 20) and the phone opens the microphone and waits for the user to speak. Only works while the user's voice session is on.",
    inputSchema: {
      type: "object",
      properties: { wait_seconds: { type: "number" } },
    },
  },
];

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const m = url.pathname.match(/^\/t\/([A-Za-z0-9]{32,})\/(mcp|poll|result|clients)$/);
    if (!m) return new Response("not found", { status: 404 });
    const stub = env.HUB.get(env.HUB.idFromName(m[1]));
    const u = new URL(request.url);
    u.pathname = "/" + m[2];
    return stub.fetch(new Request(u, request));
  },
};

export class Hub {
  constructor(state) {
    this.state = state;
    this.queue = [];
    this.waiter = null;
    this.pending = new Map();
  }

  async fetch(request) {
    const path = new URL(request.url).pathname;
    if (path === "/mcp") return this.mcp(request);
    if (path === "/poll") return this.poll();
    if (path === "/result") {
      const b = await request.json();
      const done = this.pending.get(b.id);
      if (done) {
        this.pending.delete(b.id);
        done(String(b.result));
      }
      return new Response("ok");
    }
    if (path === "/clients") {
      return Response.json((await this.state.storage.get("clients")) || {});
    }
    return new Response("not found", { status: 404 });
  }

  send(cmd) {
    if (this.waiter) {
      const w = this.waiter;
      this.waiter = null;
      w(cmd);
    } else {
      this.queue.push(cmd);
    }
  }

  async poll() {
    if (this.queue.length) return Response.json(this.queue.shift());
    const cmd = await new Promise((res) => {
      this.waiter = res;
      setTimeout(() => {
        if (this.waiter === res) {
          this.waiter = null;
          res(null);
        }
      }, 20000);
    });
    return cmd ? Response.json(cmd) : new Response(null, { status: 204 });
  }

  async mcp(request) {
    if (request.method !== "POST") return new Response("POST only", { status: 405 });
    const msg = await request.json();
    const { id, method, params } = msg;
    if (id === undefined) return new Response(null, { status: 202 });
    const reply = (result) => Response.json({ jsonrpc: "2.0", id, result });

    switch (method) {
      case "initialize": {
        const ci = (params && params.clientInfo) || {};
        const name = ci.name || "unknown";
        const clients = (await this.state.storage.get("clients")) || {};
        clients[name] = { name, version: ci.version || "", last: Date.now() };
        await this.state.storage.put("clients", clients);
        return reply({
          protocolVersion: (params && params.protocolVersion) || "2025-03-26",
          capabilities: { tools: {} },
          serverInfo: { name: "ai-bubble", version: "0.1.0" },
        });
      }
      case "ping":
        return reply({});
      case "tools/list":
        return reply({ tools: TOOLS });
      case "tools/call": {
        const cid = crypto.randomUUID();
        const text = await new Promise((res) => {
          this.pending.set(cid, res);
          this.send({ id: cid, tool: params.name, args: params.arguments || {} });
          setTimeout(() => {
            if (this.pending.delete(cid)) {
              res("timeout: the phone did not answer. Is the AI Bubble accessibility service on?");
            }
          }, 25000);
        });
        let content;
        if (text.startsWith("IMG:")) {
          content = [
            { type: "image", data: text.slice(4), mimeType: "image/jpeg" },
            { type: "text", text: "Screenshot of the phone screen (reduced size)." },
          ];
        } else {
          content = [{ type: "text", text }];
        }
        return reply({ content });
      }
      default:
        return Response.json({ jsonrpc: "2.0", id, error: { code: -32601, message: "Method not found" } });
    }
  }
}
