package com.aibubble

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast

class VoiceTile : TileService() {
    override fun onStartListening() {
        refresh()
    }

    override fun onClick() {
        val s = BridgeService.instance
        if (s == null) {
            Toast.makeText(this, "Turn on the AI Bubble accessibility service first", Toast.LENGTH_LONG).show()
            return
        }
        s.toggleVoice()
        refresh()
    }

    private fun refresh() {
        val t = qsTile ?: return
        t.label = "AI voice"
        t.state = if (BridgeService.instance?.voiceOn == true) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.updateTile()
    }
}
