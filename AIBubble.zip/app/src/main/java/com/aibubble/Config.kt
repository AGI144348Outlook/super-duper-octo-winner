package com.aibubble

import android.content.Context
import java.util.UUID

object Config {
    private fun p(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun relay(c: Context): String = p(c).getString("relay", "") ?: ""

    fun setRelay(c: Context, v: String) {
        p(c).edit().putString("relay", v.trim().trimEnd('/')).apply()
    }

    fun token(c: Context): String {
        var t = p(c).getString("token", null)
        if (t == null) {
            t = UUID.randomUUID().toString().replace("-", "") + UUID.randomUUID().toString().replace("-", "")
            p(c).edit().putString("token", t).apply()
        }
        return t
    }

    fun base(c: Context): String = relay(c) + "/t/" + token(c)

    fun mcpUrl(c: Context): String = base(c) + "/mcp"
}
