package com.aibubble

import android.content.Context
import java.util.UUID

object Config {
    private fun p(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun relay(c: Context): String = p(c).getString("relay", "") ?: ""

    // Accepts a plain relay URL, or a full MCP URL (restores relay + token together).
    fun setRelay(c: Context, v: String) {
        val t = v.trim()
        val m = Regex("^(https?://[^/]+)/t/([A-Za-z0-9]{32,})(/.*)?$").find(t)
        if (m != null) {
            p(c).edit().putString("relay", m.groupValues[1]).putString("token", m.groupValues[2]).apply()
        } else {
            p(c).edit().putString("relay", t.trimEnd('/')).apply()
        }
    }

    fun token(c: Context): String {
        var t = p(c).getString("token", null)
        if (t == null) {
            t = UUID.randomUUID().toString().replace("-", "") + UUID.randomUUID().toString().replace("-", "")
            p(c).edit().putString("token", t).apply()
        }
        return t
    }

    fun base(c: Context): String = relay(c) + "/t/" + token(c)

    fun mcpUrl(c: Context): String = base(c) + "/mcp"

    // Extra keywords (comma separated) for apps that must end a screen session.
    fun extraBlock(c: Context): List<String> =
        (p(c).getString("block", "") ?: "").split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }

    fun setExtraBlock(c: Context, v: String) {
        p(c).edit().putString("block", v).apply()
    }
}
