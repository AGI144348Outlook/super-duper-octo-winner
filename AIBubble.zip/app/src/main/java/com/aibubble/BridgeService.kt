package com.aibubble

import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as WLP
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.ImageView
import android.widget.Toast
import org.json.JSONObject
import kotlin.math.abs

class BridgeService : AccessibilityService() {
    companion object {
        @Volatile
        var instance: BridgeService? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private val heads = mutableListOf<View>()
    private var highlightView: View? = null
    @Volatile
    private var running = false

    private var ps: List<Platform> = emptyList()
    private var active: Platform? = null
    private var currentPkg: String? = null
    private var lastOtherPkg: String? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        running = true
        Thread { pollLoop() }.start()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg.contains("systemui") || pkg.contains("inputmethod")) return
        currentPkg = pkg
        if (Platforms.all.none { it.pkg == pkg }) lastOtherPkg = pkg
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        running = false
        instance = null
        main.post {
            removeHeads()
            clearHighlight()
        }
        return super.onUnbind(intent)
    }

    // ---- relay polling ----

    private fun pollLoop() {
        while (running) {
            try {
                if (Config.relay(this).isBlank()) {
                    Thread.sleep(3000)
                    continue
                }
                val (code, body) = Net.request(Config.base(this) + "/poll", readTimeout = 30000)
                if (code == 200) {
                    val cmd = JSONObject(body)
                    val result = try {
                        runTool(cmd.getString("tool"), cmd.optJSONObject("args") ?: JSONObject())
                    } catch (e: Exception) {
                        "error: " + e.message
                    }
                    val payload = JSONObject().put("id", cmd.getString("id")).put("result", result).toString()
                    Net.request(Config.base(this) + "/result", "POST", payload)
                } else if (code != 204) {
                    Thread.sleep(3000)
                }
            } catch (e: Exception) {
                try {
                    Thread.sleep(3000)
                } catch (ie: InterruptedException) {
                }
            }
        }
    }

    private fun runTool(tool: String, args: JSONObject): String = when (tool) {
        "read_screen" -> readScreen()
        "highlight" -> highlight(args)
        "clear_highlight" -> {
            main.post { clearHighlight() }
            "cleared"
        }
        else -> "unknown tool: $tool"
    }

    // ---- screen reading ----

    private fun readScreen(): String {
        val root = rootInActiveWindow ?: return "no active window"
        val dm = resources.displayMetrics
        val sb = StringBuilder()
        sb.append("app=").append(root.packageName).append(" screen=").append(dm.widthPixels).append("x").append(dm.heightPixels).append("\n")
        var n = 0
        fun walk(node: AccessibilityNodeInfo?) {
            if (node == null || n >= 250) return
            if (node.isVisibleToUser) {
                val t = node.text?.toString()
                val d = node.contentDescription?.toString()
                if (!t.isNullOrBlank() || !d.isNullOrBlank() || node.isClickable) {
                    val r = Rect()
                    node.getBoundsInScreen(r)
                    sb.append("- ")
                    if (!t.isNullOrBlank()) sb.append("text=\"").append(t.take(120)).append("\" ")
                    if (!d.isNullOrBlank()) sb.append("desc=\"").append(d.take(120)).append("\" ")
                    if (node.isClickable) sb.append("clickable ")
                    sb.append("bounds=").append(r.left).append(',').append(r.top).append(',').append(r.right).append(',').append(r.bottom).append("\n")
                    n++
                }
            }
            for (i in 0 until node.childCount) walk(node.getChild(i))
        }
        walk(root)
        return sb.toString()
    }

    // ---- highlight ----

    private fun highlight(args: JSONObject): String {
        val rect = Rect()
        val text = args.optString("text", "")
        if (text.isNotBlank()) {
            val root = rootInActiveWindow ?: return "no active window"
            val node = root.findAccessibilityNodeInfosByText(text).firstOrNull { it.isVisibleToUser }
                ?: return "not found on screen: $text"
            node.getBoundsInScreen(rect)
        } else if (args.has("x") && args.has("y")) {
            val x = args.getInt("x")
            val y = args.getInt("y")
            rect.set(x, y, x + args.optInt("width", 200), y + args.optInt("height", 100))
        } else {
            return "give either text, or x, y, width, height"
        }
        main.post { showHighlight(rect) }
        return "highlighted " + rect.flattenToString()
    }

    private fun showHighlight(r: Rect) {
        clearHighlight()
        val v = View(this)
        v.background = GradientDrawable().apply {
            setColor(0x33FFEB3B)
            setStroke(8, 0xFFFF9800.toInt())
            cornerRadius = 16f
        }
        val lp = WLP(
            maxOf(r.width(), 20), maxOf(r.height(), 20),
            WLP.TYPE_ACCESSIBILITY_OVERLAY,
            WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_NOT_TOUCHABLE or WLP.FLAG_LAYOUT_IN_SCREEN or WLP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = r.left
        lp.y = r.top
        wm.addView(v, lp)
        highlightView = v
        main.postDelayed({ if (highlightView === v) clearHighlight() }, 8000)
    }

    private fun clearHighlight() {
        highlightView?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        highlightView = null
    }

    // ---- heads: expanded row at the top, collapsed single bubble ----

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun statusBarH(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else dp(24)
    }

    // Called by the launcher: show the row with p active.
    fun expand(list: List<Platform>, p: Platform) {
        main.post {
            ps = list
            active = p
            showRow()
        }
    }

    private fun makeHead(p: Platform, ring: Boolean): ImageView? {
        val icon = try {
            packageManager.getApplicationIcon(p.pkg)
        } catch (e: Exception) {
            return null
        }
        val v = ImageView(this)
        v.setImageDrawable(icon)
        v.scaleType = ImageView.ScaleType.CENTER_CROP
        v.setPadding(dp(3), dp(3), dp(3), dp(3))
        v.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.WHITE)
            if (ring) setStroke(dp(3), 0xFF26C6DA.toInt())
        }
        v.clipToOutline = true
        v.elevation = 8f
        return v
    }

    private fun showRow() {
        removeHeads()
        val size = dp(52)
        val gap = dp(14)
        val total = ps.size * size + (ps.size - 1) * gap
        var x = (resources.displayMetrics.widthPixels - total) / 2
        val y = statusBarH() + dp(6)
        for (p in ps) {
            val v = makeHead(p, p == active) ?: continue
            val lp = WLP(
                size, size,
                WLP.TYPE_ACCESSIBILITY_OVERLAY,
                WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            lp.x = x
            lp.y = y
            v.setOnTouchListener(tapOrHold { onHeadTap(p) })
            wm.addView(v, lp)
            heads.add(v)
            x += size + gap
        }
    }

    private fun showBubble() {
        removeHeads()
        val a = active ?: ps.firstOrNull() ?: return
        val v = makeHead(a, false) ?: return
        val size = dp(52)
        val lp = WLP(
            size, size,
            WLP.TYPE_ACCESSIBILITY_OVERLAY,
            WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = statusBarH() + dp(80)
        attachTouch(v, lp) {
            main.post {
                showRow()
                launch(a)
            }
        }
        wm.addView(v, lp)
        heads.add(v)
    }

    private fun onHeadTap(p: Platform) {
        val inside = currentPkg == p.pkg || rootInActiveWindow?.packageName?.toString() == p.pkg
        if (p == active && inside) {
            // minimize: collapse to one bubble and go back to the previous app
            main.post {
                showBubble()
                returnToPrevious()
            }
        } else {
            active = p
            main.post {
                showRow()
                launch(p)
            }
        }
    }

    private fun returnToPrevious() {
        val back = lastOtherPkg
        val i = if (back != null) packageManager.getLaunchIntentForPackage(back) else null
        if (i == null) {
            performGlobalAction(GLOBAL_ACTION_HOME)
            return
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(i)
        } catch (e: Exception) {
            performGlobalAction(GLOBAL_ACTION_HOME)
        }
    }

    private fun dismissAll() {
        removeHeads()
    }

    private fun removeHeads() {
        heads.forEach {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        heads.clear()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun tapOrHold(onTap: () -> Unit): View.OnTouchListener {
        var held = false
        val hold = Runnable {
            held = true
            dismissAll()
        }
        return View.OnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    held = false
                    main.postDelayed(hold, 700)
                }
                MotionEvent.ACTION_UP -> {
                    main.removeCallbacks(hold)
                    if (!held) onTap()
                }
                MotionEvent.ACTION_CANCEL -> main.removeCallbacks(hold)
            }
            true
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attachTouch(v: View, lp: WLP, onTap: () -> Unit) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        var longFired = false
        val longRun = Runnable {
            if (!moved) {
                longFired = true
                dismissAll()
            }
        }
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX
                    sy = e.rawY
                    ox = lp.x
                    oy = lp.y
                    moved = false
                    longFired = false
                    main.postDelayed(longRun, 700)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (abs(dx) > 15 || abs(dy) > 15) {
                        moved = true
                        main.removeCallbacks(longRun)
                    }
                    if (moved) {
                        lp.x = ox + dx.toInt()
                        lp.y = oy + dy.toInt()
                        try {
                            wm.updateViewLayout(v, lp)
                        } catch (ex: Exception) {
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    main.removeCallbacks(longRun)
                    if (!moved && !longFired) onTap()
                }
                MotionEvent.ACTION_CANCEL -> main.removeCallbacks(longRun)
            }
            true
        }
    }

    private fun launch(p: Platform) {
        val i = packageManager.getLaunchIntentForPackage(p.pkg) ?: return
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "Couldn't open " + p.name, Toast.LENGTH_SHORT).show()
        }
    }
}
