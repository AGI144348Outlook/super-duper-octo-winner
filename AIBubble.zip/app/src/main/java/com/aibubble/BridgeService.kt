package com.aibubble

import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as WLP
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.util.Locale
import java.util.UUID
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.hypot

class BridgeService : AccessibilityService() {
    companion object {
        @Volatile
        var instance: BridgeService? = null

        const val SCREEN_OFF = "Screen session is off. Ask the user to tap the screen button on their phone to start one."
        const val VOICE_OFF = "Voice session is off. Ask the user to tap the voice button on their phone to turn it on."
        const val CANCEL = "\u0000"
        const val LABEL_SCREEN = "\u05E2"
        const val LABEL_VOICE = "\u05E4"
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private val heads = mutableListOf<View>()
    private var highlightView: View? = null
    private var xView: View? = null
    @Volatile
    private var running = false

    private var ps: List<Platform> = emptyList()
    private var active: Platform? = null
    private var currentPkg: String? = null
    private var lastOtherPkg: String? = null

    // sessions
    @Volatile
    var screenOn = false
    @Volatile
    var screenPending = false
    @Volatile
    var voiceOn = false
    private var screenBtn: TextView? = null
    private var voiceBtn: TextView? = null
    private var btnLps: Pair<WLP, WLP>? = null

    // voice
    private var tts: TextToSpeech? = null
    @Volatile
    private var ttsReady = false
    private val transcripts = LinkedBlockingQueue<String>()

    private val offReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            stopScreen("the phone was locked")
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        running = true
        tts = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) tts?.language = Locale.getDefault()
        }
        try {
            registerReceiver(offReceiver, IntentFilter(Intent.ACTION_SCREEN_OFF))
        } catch (e: Exception) {
        }
        Thread { pollLoop() }.start()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg.contains("systemui") || pkg.contains("inputmethod")) return
        currentPkg = pkg
        if (Platforms.all.none { it.pkg == pkg }) lastOtherPkg = pkg
        if (screenOn && Sensitive.matches(this, pkg)) stopScreen("a sensitive app was opened")
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        running = false
        instance = null
        try {
            unregisterReceiver(offReceiver)
        } catch (e: Exception) {
        }
        tts?.shutdown()
        CaptureService.instance?.shutdown()
        main.post {
            voiceOn = false
            screenOn = false
            screenPending = false
            updateNote()
            removeHeads()
            hideX()
            clearHighlight()
        }
        return super.onUnbind(intent)
    }

    // ---- relay polling ----

    private fun pollLoop() {
        while (running) {
            try {
                if (Config.relay(this).isBlank()) {
                    Thread.sleep(3000)
                    continue
                }
                val (code, body) = Net.request(Config.base(this) + "/poll", readTimeout = 30000)
                if (code == 200) {
                    val cmd = JSONObject(body)
                    val result = try {
                        runTool(cmd.getString("tool"), cmd.optJSONObject("args") ?: JSONObject())
                    } catch (e: Exception) {
                        "error: " + e.message
                    }
                    val payload = JSONObject().put("id", cmd.getString("id")).put("result", result).toString()
                    Net.request(Config.base(this) + "/result", "POST", payload)
                } else if (code != 204) {
                    Thread.sleep(3000)
                }
            } catch (e: Exception) {
                try {
                    Thread.sleep(3000)
                } catch (ie: InterruptedException) {
                }
            }
        }
    }

    private fun runTool(tool: String, args: JSONObject): String = when (tool) {
        "session_status" ->
            "screen_session=" + (if (screenOn) "on" else "off") + ", voice_session=" + (if (voiceOn) "on" else "off")
        "read_screen" -> if (screenOn) readScreen() else SCREEN_OFF
        "highlight" -> if (screenOn) highlight(args) else SCREEN_OFF
        "take_screenshot" -> if (screenOn) screenshot() else SCREEN_OFF
        "clear_highlight" -> {
            main.post { clearHighlight() }
            "cleared"
        }
        "speak_text" -> if (voiceOn) speak(args.optString("text", "")) else VOICE_OFF
        "get_speech_transcript" -> if (voiceOn) getTranscript(args) else VOICE_OFF
        else -> "unknown tool: $tool"
    }

    // ---- voice ----

    private fun speak(text: String): String {
        if (text.isBlank()) return "no text given"
        val t = tts
        if (t == null || !ttsReady) return "the phone's speech engine is not ready"
        t.speak(text.take(1500), TextToSpeech.QUEUE_ADD, null, UUID.randomUUID().toString())
        return "speaking"
    }

    private fun getTranscript(args: JSONObject): String {
        val wait = args.optInt("wait_seconds", 0).coerceIn(0, 20)
        val got = ArrayList<String>()
        while (true) {
            val t = transcripts.poll() ?: break
            got.add(t)
        }
        if (got.isEmpty() && wait > 0) {
            main.post { openVoiceDialog() }
            val t = transcripts.poll(wait.toLong(), TimeUnit.SECONDS)
            if (t != null) got.add(t)
        }
        val real = got.filter { it != CANCEL }
        return when {
            real.isNotEmpty() -> "User said: " + real.joinToString(" | ")
            got.isNotEmpty() -> "The user closed the microphone without speaking."
            else -> "Nothing said yet."
        }
    }

    // Called by VoiceActivity with the recognized words, or null if cancelled.
    fun onTranscript(text: String?) {
        transcripts.offer(if (text.isNullOrBlank()) CANCEL else text)
    }

    private fun openVoiceDialog() {
        val i = Intent(this, VoiceActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(i)
        } catch (e: Exception) {
            toast("Couldn't open the microphone")
            transcripts.offer(CANCEL)
        }
    }

    fun toggleVoice() {
        main.post {
            voiceOn = !voiceOn
            if (!voiceOn) tts?.stop()
            refreshButtons()
            updateNote()
            toast(if (voiceOn) "Voice session on" else "Voice session off")
        }
    }

    private fun talkNow() {
        if (voiceOn) openVoiceDialog()
    }

    private fun updateNote() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (!voiceOn) {
            nm.cancel(2)
            return
        }
        nm.createNotificationChannel(NotificationChannel("status", "Session status", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "status")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("AI Bubble voice session is on")
            .setContentText("Tap the voice button on the bubble to turn it off")
            .setOngoing(true)
            .build()
        nm.notify(2, n)
    }

    private fun toast(msg: String) {
        main.post { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
    }

    // ---- screen session ----

    fun beginPending() {
        main.post {
            screenPending = true
            refreshButtons()
        }
    }

    fun toggleScreen() {
        if (screenOn || screenPending) {
            stopScreen("stopped")
        } else {
            beginPending()
            val i = Intent(this, ProjectionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                startActivity(i)
            } catch (e: Exception) {
                stopScreen("could not open the capture prompt")
            }
        }
    }

    fun onScreenStarted() {
        main.post {
            screenPending = false
            screenOn = true
            refreshButtons()
            toast("Screen session on")
        }
    }

    fun stopScreen(reason: String) {
        main.post {
            val was = screenOn || screenPending
            screenOn = false
            screenPending = false
            clearHighlight()
            CaptureService.instance?.shutdown()
            refreshButtons()
            if (was) toast("Screen session ended: $reason")
        }
    }

    private fun screenshot(): String {
        val cs = CaptureService.instance ?: return "Capture is not ready yet. Try again in a moment."
        val r = cs.grab() ?: return "No frame yet. Try again."
        if (r == "BLANK") {
            stopScreen("the screen looked blank or protected")
            return "Session ended: the screen looked blank or protected, so capture was stopped."
        }
        return "IMG:$r"
    }

    // ---- screen reading ----

    private fun readScreen(): String {
        val root = rootInActiveWindow ?: return "no active window"
        val dm = resources.displayMetrics
        val sb = StringBuilder()
        sb.append("app=").append(root.packageName).append(" screen=").append(dm.widthPixels).append("x").append(dm.heightPixels).append("\n")
        var n = 0
        fun walk(node: AccessibilityNodeInfo?) {
            if (node == null || n >= 250) return
            if (node.isVisibleToUser) {
                val t = node.text?.toString()
                val d = node.contentDescription?.toString()
                if (!t.isNullOrBlank() || !d.isNullOrBlank() || node.isClickable) {
                    val r = Rect()
                    node.getBoundsInScreen(r)
                    sb.append("- ")
                    if (!t.isNullOrBlank()) sb.append("text=\"").append(t.take(120)).append("\" ")
                    if (!d.isNullOrBlank()) sb.append("desc=\"").append(d.take(120)).append("\" ")
                    if (node.isClickable) sb.append("clickable ")
                    sb.append("bounds=").append(r.left).append(',').append(r.top).append(',').append(r.right).append(',').append(r.bottom).append("\n")
                    n++
                }
            }
            for (i in 0 until node.childCount) walk(node.getChild(i))
        }
        walk(root)
        return sb.toString()
    }

    // ---- highlight ----

    private fun highlight(args: JSONObject): String {
        val rect = Rect()
        val text = args.optString("text", "")
        if (text.isNotBlank()) {
            val root = rootInActiveWindow ?: return "no active window"
            val node = root.findAccessibilityNodeInfosByText(text).firstOrNull { it.isVisibleToUser }
                ?: return "not found on screen: $text"
            node.getBoundsInScreen(rect)
        } else if (args.has("x") && args.has("y")) {
            val x = args.getInt("x")
            val y = args.getInt("y")
            rect.set(x, y, x + args.optInt("width", 200), y + args.optInt("height", 100))
        } else {
            return "give either text, or x, y, width, height"
        }
        main.post { showHighlight(rect) }
        return "highlighted " + rect.flattenToString()
    }

    private fun showHighlight(r: Rect) {
        clearHighlight()
        val v = View(this)
        v.background = GradientDrawable().apply {
            setColor(0x33FFEB3B)
            setStroke(8, 0xFFFF9800.toInt())
            cornerRadius = 16f
        }
        val lp = WLP(
            maxOf(r.width(), 20), maxOf(r.height(), 20),
            WLP.TYPE_ACCESSIBILITY_OVERLAY,
            WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_NOT_TOUCHABLE or WLP.FLAG_LAYOUT_IN_SCREEN or WLP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = r.left
        lp.y = r.top
        wm.addView(v, lp)
        highlightView = v
        main.postDelayed({ if (highlightView === v) clearHighlight() }, 8000)
    }

    private fun clearHighlight() {
        highlightView?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        highlightView = null
    }

    // ---- heads: expanded row at the top, collapsed single bubble ----

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun statusBarH(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else dp(24)
    }

    // Called by the launcher: show the row with p active.
    fun expand(list: List<Platform>, p: Platform) {
        main.post {
            ps = list
            active = p
            showRow()
        }
    }

    private fun makeHead(p: Platform, ring: Boolean): ImageView? {
        val icon = try {
            packageManager.getApplicationIcon(p.pkg)
        } catch (e: Exception) {
            return null
        }
        val v = ImageView(this)
        v.setImageDrawable(icon)
        v.scaleType = ImageView.ScaleType.CENTER_CROP
        v.setPadding(dp(3), dp(3), dp(3), dp(3))
        v.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.WHITE)
            if (ring) setStroke(dp(3), 0xFF26C6DA.toInt())
        }
        v.clipToOutline = true
        v.elevation = 8f
        return v
    }

    private fun overlayParams(w: Int, h: Int): WLP {
        val lp = WLP(
            w, h,
            WLP.TYPE_ACCESSIBILITY_OVERLAY,
            WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        return lp
    }

    private fun showRow() {
        removeHeads()
        val size = dp(52)
        val gap = dp(14)
        val total = ps.size * size + (ps.size - 1) * gap
        val sw = resources.displayMetrics.widthPixels
        var x = (sw - total) / 2
        val y = statusBarH() + dp(6)
        for (p in ps) {
            val v = makeHead(p, p == active) ?: continue
            val lp = overlayParams(size, size)
            lp.x = x
            lp.y = y
            v.setOnTouchListener(dragTouch(v, lp, false) { onHeadTap(p) })
            wm.addView(v, lp)
            heads.add(v)
            x += size + gap
        }
        addButtons(sw / 2, y + size + dp(8))
    }

    private fun showBubble() {
        removeHeads()
        val a = active ?: ps.firstOrNull() ?: return
        val v = makeHead(a, false) ?: return
        val size = dp(52)
        val lp = overlayParams(size, size)
        lp.x = 0
        lp.y = statusBarH() + dp(80)
        v.setOnTouchListener(dragTouch(v, lp, true) {
            main.post {
                showRow()
                launch(a)
            }
        })
        wm.addView(v, lp)
        heads.add(v)
        addButtons(lp.x + size / 2, lp.y + size + dp(8))
    }

    private fun onHeadTap(p: Platform) {
        val inside = currentPkg == p.pkg || rootInActiveWindow?.packageName?.toString() == p.pkg
        if (p == active && inside) {
            // minimize: collapse to one bubble and go back to the previous app
            main.post {
                showBubble()
                returnToPrevious()
            }
        } else {
            active = p
            main.post {
                showRow()
                launch(p)
            }
        }
    }

    private fun returnToPrevious() {
        val back = lastOtherPkg
        val i = if (back != null) packageManager.getLaunchIntentForPackage(back) else null
        if (i == null) {
            performGlobalAction(GLOBAL_ACTION_HOME)
            return
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(i)
        } catch (e: Exception) {
            performGlobalAction(GLOBAL_ACTION_HOME)
        }
    }

    // Close everything: heads, buttons, and both sessions.
    private fun dismissAll() {
        removeHeads()
        hideX()
        stopScreen("closed")
        if (voiceOn) {
            voiceOn = false
            tts?.stop()
            updateNote()
        }
    }

    private fun removeHeads() {
        heads.forEach {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        heads.clear()
        screenBtn = null
        voiceBtn = null
        btnLps = null
    }

    // ---- the two session buttons ----

    private fun darken(c: Int, f: Float): Int =
        Color.rgb((Color.red(c) * f).toInt(), (Color.green(c) * f).toInt(), (Color.blue(c) * f).toInt())

    private fun makeBtn(label: String): TextView {
        val v = TextView(this)
        v.text = label
        v.gravity = Gravity.CENTER
        v.textSize = 20f
        v.setTextColor(Color.WHITE)
        v.setTypeface(null, Typeface.BOLD)
        return v
    }

    // state: 0 = off (raised), 1 = on (pressed in, colored), 2 = waiting for the system prompt
    private fun styleBtn(v: TextView, state: Int, color: Int) {
        val size = dp(44)
        val grey = 0xFF8A8F94.toInt()
        when (state) {
            1 -> {
                val g = GradientDrawable()
                g.shape = GradientDrawable.OVAL
                g.gradientType = GradientDrawable.RADIAL_GRADIENT
                g.gradientRadius = size * 0.65f
                g.setGradientCenter(0.5f, 0.6f)
                g.colors = intArrayOf(color, darken(color, 0.55f))
                g.setStroke(dp(2), darken(color, 0.35f))
                v.background = g
                v.translationY = dp(2).toFloat()
            }
            2 -> {
                val g = GradientDrawable()
                g.shape = GradientDrawable.OVAL
                g.setColor(darken(grey, 0.8f))
                g.setStroke(dp(3), color)
                v.background = g
                v.translationY = dp(1).toFloat()
            }
            else -> {
                val shadow = GradientDrawable()
                shadow.shape = GradientDrawable.OVAL
                shadow.setColor(0x66000000)
                val face = GradientDrawable(
                    GradientDrawable.Orientation.TOP_BOTTOM,
                    intArrayOf(0xFFB4B9BE.toInt(), 0xFF7A7F84.toInt())
                )
                face.shape = GradientDrawable.OVAL
                val ld = LayerDrawable(arrayOf(shadow, face))
                ld.setLayerInset(1, 0, 0, 0, dp(3))
                v.background = ld
                v.translationY = 0f
            }
        }
    }

    private fun refreshButtons() {
        screenBtn?.let { styleBtn(it, if (screenOn) 1 else if (screenPending) 2 else 0, 0xFF43A047.toInt()) }
        voiceBtn?.let { styleBtn(it, if (voiceOn) 1 else 0, 0xFFFFA000.toInt()) }
    }

    private fun clampCx(cx: Int): Int {
        val half = dp(44) + dp(7)
        val sw = resources.displayMetrics.widthPixels
        return cx.coerceIn(half + dp(4), sw - half - dp(4))
    }

    private fun addButtons(centerX: Int, top: Int) {
        val size = dp(44)
        val gap = dp(14)
        val cx = clampCx(centerX)
        val sb = makeBtn(LABEL_SCREEN)
        val vb = makeBtn(LABEL_VOICE)
        val l1 = overlayParams(size, size + dp(3))
        l1.x = cx - gap / 2 - size
        l1.y = top
        val l2 = overlayParams(size, size + dp(3))
        l2.x = cx + gap / 2
        l2.y = top
        sb.setOnTouchListener(btnTouch({ toggleScreen() }, null))
        vb.setOnTouchListener(btnTouch({ toggleVoice() }, { talkNow() }))
        wm.addView(sb, l1)
        wm.addView(vb, l2)
        heads.add(sb)
        heads.add(vb)
        screenBtn = sb
        voiceBtn = vb
        btnLps = Pair(l1, l2)
        refreshButtons()
    }

    private fun moveButtons(centerX: Int, top: Int) {
        val lps = btnLps ?: return
        val size = dp(44)
        val gap = dp(14)
        val cx = clampCx(centerX)
        lps.first.x = cx - gap / 2 - size
        lps.first.y = top
        lps.second.x = cx + gap / 2
        lps.second.y = top
        try {
            screenBtn?.let { wm.updateViewLayout(it, lps.first) }
            voiceBtn?.let { wm.updateViewLayout(it, lps.second) }
        } catch (e: Exception) {
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun btnTouch(onTap: () -> Unit, onLong: (() -> Unit)?): View.OnTouchListener {
        var longFired = false
        val lr = Runnable {
            longFired = true
            onLong?.invoke()
        }
        return View.OnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    longFired = false
                    if (onLong != null) main.postDelayed(lr, 600)
                }
                MotionEvent.ACTION_UP -> {
                    main.removeCallbacks(lr)
                    if (!longFired) onTap()
                }
                MotionEvent.ACTION_CANCEL -> main.removeCallbacks(lr)
            }
            true
        }
    }

    // ---- drag a head down to the X to close everything ----

    private fun xCenterY(): Float = resources.displayMetrics.heightPixels - dp(150) + dp(32).toFloat()

    private fun showX() {
        if (xView != null) return
        val s = dp(64)
        val v = TextView(this)
        v.text = "\u2715"
        v.textSize = 26f
        v.gravity = Gravity.CENTER
        v.setTextColor(Color.WHITE)
        v.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0xCC37474F.toInt())
        }
        val lp = WLP(
            s, s,
            WLP.TYPE_ACCESSIBILITY_OVERLAY,
            WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_NOT_TOUCHABLE or WLP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = resources.displayMetrics.widthPixels / 2 - s / 2
        lp.y = resources.displayMetrics.heightPixels - dp(150)
        wm.addView(v, lp)
        xView = v
    }

    private fun overX(x: Float, y: Float): Boolean =
        hypot(x - resources.displayMetrics.widthPixels / 2f, y - xCenterY()) < dp(70)

    private fun setXHot(hot: Boolean) {
        xView?.let {
            (it.background as? GradientDrawable)?.setColor(if (hot) 0xFFD32F2F.toInt() else 0xCC37474F.toInt())
            val sc = if (hot) 1.25f else 1f
            it.scaleX = sc
            it.scaleY = sc
        }
    }

    private fun hideX() {
        xView?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        xView = null
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun dragTouch(v: View, lp: WLP, isBubble: Boolean, onTap: () -> Unit): View.OnTouchListener {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        return View.OnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX
                    sy = e.rawY
                    ox = lp.x
                    oy = lp.y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (!moved && (abs(dx) > dp(8) || abs(dy) > dp(8))) {
                        moved = true
                        showX()
                    }
                    if (moved) {
                        lp.x = ox + dx.toInt()
                        lp.y = oy + dy.toInt()
                        try {
                            wm.updateViewLayout(v, lp)
                        } catch (ex: Exception) {
                        }
                        if (isBubble) moveButtons(lp.x + lp.width / 2, lp.y + lp.height + dp(8))
                        setXHot(overX(e.rawX, e.rawY))
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        onTap()
                    } else {
                        val hot = overX(e.rawX, e.rawY)
                        hideX()
                        if (hot) {
                            main.post { dismissAll() }
                        } else if (!isBubble) {
                            main.post { showRow() }
                        }
                    }
                }
                MotionEvent.ACTION_CANCEL -> {
                    if (moved) {
                        hideX()
                        if (!isBubble) main.post { showRow() }
                    }
                }
            }
            true
        }
    }

    private fun launch(p: Platform) {
        val i = packageManager.getLaunchIntentForPackage(p.pkg) ?: return
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "Couldn't open " + p.name, Toast.LENGTH_SHORT).show()
        }
    }
}
