package com.aibubble

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var mcp: TextView
    private lateinit var relay: EditText
    private lateinit var listBox: LinearLayout
    private var clients = listOf<String>()

    private val refresh = object : Runnable {
        override fun run() {
            fetch()
            h.postDelayed(this, 4000)
        }
    }

    private fun tv(t: String) = TextView(this).apply {
        text = t
        textSize = 16f
        setPadding(0, 16, 0, 16)
    }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t
        setOnClickListener { f() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 80, 40, 40)
        }
        setContentView(ScrollView(this).apply { addView(root) })

        root.addView(tv("AI Bubble").apply { textSize = 26f })

        root.addView(tv("1. Relay URL (your deployed Cloudflare Worker)"))
        relay = EditText(this).apply {
            setText(Config.relay(this@MainActivity))
            hint = "https://ai-bubble-relay.yourname.workers.dev"
            inputType = InputType.TYPE_TEXT_VARIATION_URI
        }
        root.addView(relay)
        root.addView(btn("Save") {
            Config.setRelay(this, relay.text.toString())
            updateMcp()
        })

        root.addView(tv("2. Add this as a custom MCP connector in your AI app (no authentication)"))
        mcp = tv("").apply { setTextIsSelectable(true) }
        root.addView(mcp)
        root.addView(btn("Copy MCP URL") {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("mcp", Config.mcpUrl(this)))
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
        })

        root.addView(tv("3. Turn on the accessibility service"))
        status = tv("")
        root.addView(status)
        root.addView(btn("Open accessibility settings") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        root.addView(tv("Connected AIs").apply { textSize = 20f })
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(listBox)
        renderList()
    }

    override fun onResume() {
        super.onResume()
        updateMcp()
        status.text = if (a11yOn()) "Accessibility: on" else "Accessibility: OFF. Turn on AI Bubble (needed for heads and screen reading)."
        h.post(refresh)
    }

    override fun onPause() {
        super.onPause()
        h.removeCallbacks(refresh)
    }

    private fun updateMcp() {
        mcp.text = if (Config.relay(this).isBlank()) "Save the relay URL first" else Config.mcpUrl(this)
    }

    private fun a11yOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(packageName)
    }

    private fun fetch() {
        if (Config.relay(this).isBlank()) return
        Thread {
            try {
                val (code, body) = Net.request(Config.base(this) + "/clients")
                if (code == 200) {
                    val o = JSONObject(body)
                    val names = o.keys().asSequence().map { o.getJSONObject(it).optString("name", it) }.toList()
                    runOnUiThread {
                        clients = names
                        renderList()
                    }
                }
            } catch (e: Exception) {
            }
        }.start()
    }

    private fun renderList() {
        listBox.removeAllViews()
        if (clients.isEmpty()) {
            listBox.addView(tv("No AI connected yet. Add the MCP URL above as a custom connector in your AI app, then ask it to use the read_screen tool. It will appear here."))
            return
        }
        for (name in clients) {
            val p = Platforms.match(name)
            val label = if (p == null) "$name (no app mapped)" else p.name
            listBox.addView(btn(label) { if (p != null) open(p) })
        }
    }

    private fun open(p: Platform) {
        val svc = BridgeService.instance
        if (svc == null) {
            Toast.makeText(this, "Turn on the accessibility service first", Toast.LENGTH_LONG).show()
            return
        }
        val intent = packageManager.getLaunchIntentForPackage(p.pkg)
        if (intent == null) {
            Toast.makeText(this, "${p.name} app is not installed", Toast.LENGTH_LONG).show()
            return
        }
        svc.showHeads(clients.mapNotNull { Platforms.match(it) }.distinct())
        startActivity(intent)
    }
}
