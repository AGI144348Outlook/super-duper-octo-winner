package com.aibubble

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent

// Invisible screen that shows the phone's own speech pop-up and hands the words to the service.
class VoiceActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Talk to your AI")
        try {
            startActivityForResult(i, 1)
        } catch (e: Exception) {
            BridgeService.instance?.onTranscript(null)
            finish()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val text = if (resultCode == RESULT_OK) {
            data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        } else {
            null
        }
        BridgeService.instance?.onTranscript(text)
        finish()
    }
}
