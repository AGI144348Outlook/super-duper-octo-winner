package com.aibubble

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Base64
import java.io.ByteArrayOutputStream

// Holds the screen capture for one screen session. Android requires a foreground service for this.
class CaptureService : Service() {
    companion object {
        @Volatile
        var instance: CaptureService? = null
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    @Volatile
    private var ended = false
    private var last: Bitmap? = null
    private var cw = 0
    private var ch = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "stop") {
            BridgeService.instance?.stopScreen("stopped from the notification")
            shutdown()
            return START_NOT_STICKY
        }
        ended = false
        startFg()
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null || code == 0) {
            BridgeService.instance?.stopScreen("no capture permission")
            shutdown()
            return START_NOT_STICKY
        }
        instance = this
        try {
            begin(code, data)
        } catch (e: Exception) {
            BridgeService.instance?.stopScreen("capture failed")
            shutdown()
        }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("capture", "Screen session", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, CaptureService::class.java).setAction("stop"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", stop
        ).build()
        val n = Notification.Builder(this, "capture")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("AI Bubble screen session is live")
            .setContentText("Your AI can read and capture this screen. Tap Stop to end it.")
            .setOngoing(true)
            .addAction(action)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun begin(code: Int, data: Intent) {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(code, data)
        projection = p
        // Android 14 requires a callback to be registered before the display is created.
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                BridgeService.instance?.stopScreen("capture stopped")
                shutdown()
            }
        }, Handler(Looper.getMainLooper()))
        val dm = resources.displayMetrics
        val scale = if (dm.widthPixels > 720) 720f / dm.widthPixels else 1f
        cw = (dm.widthPixels * scale).toInt()
        ch = (dm.heightPixels * scale).toInt()
        val r = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 2)
        reader = r
        display = p.createVirtualDisplay(
            "aibubble", cw, ch, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
        BridgeService.instance?.onScreenStarted()
    }

    // Returns a base64 JPEG, "BLANK" if the screen looks blank or protected, or null if no frame yet.
    fun grab(): String? {
        val r = reader ?: return null
        val img = r.acquireLatestImage()
        var bmp: Bitmap? = null
        if (img != null) {
            try {
                val w = img.width
                val h = img.height
                val pl = img.planes[0]
                val pad = pl.rowStride - pl.pixelStride * w
                val full = Bitmap.createBitmap(w + pad / pl.pixelStride, h, Bitmap.Config.ARGB_8888)
                full.copyPixelsFromBuffer(pl.buffer)
                bmp = if (full.width != w) Bitmap.createBitmap(full, 0, 0, w, h) else full
            } finally {
                img.close()
            }
            last = bmp
        } else {
            bmp = last
        }
        val b = bmp ?: return null
        if (isBlank(b)) return "BLANK"
        val out = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, 60, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    private fun isBlank(b: Bitmap): Boolean {
        val stepY = maxOf(1, b.height / 20)
        val stepX = maxOf(1, b.width / 20)
        var y = 0
        while (y < b.height) {
            var x = 0
            while (x < b.width) {
                val p = b.getPixel(x, y)
                if (maxOf(Color.red(p), Color.green(p), Color.blue(p)) > 12) return false
                x += stepX
            }
            y += stepY
        }
        return true
    }

    fun shutdown() {
        if (ended) return
        ended = true
        try {
            display?.release()
        } catch (e: Exception) {
        }
        try {
            projection?.stop()
        } catch (e: Exception) {
        }
        try {
            reader?.close()
        } catch (e: Exception) {
        }
        display = null
        reader = null
        projection = null
        last = null
        instance = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }
}
