package com.aibubble

import android.content.Intent
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast

class ScreenTile : TileService() {
    override fun onStartListening() {
        refresh()
    }

    override fun onClick() {
        val s = BridgeService.instance
        if (s == null) {
            Toast.makeText(this, "Turn on the AI Bubble accessibility service first", Toast.LENGTH_LONG).show()
            return
        }
        if (s.screenOn || s.screenPending) {
            s.stopScreen("stopped from the tile")
        } else {
            s.beginPending()
            startActivityAndCollapse(Intent(this, ProjectionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        refresh()
    }

    private fun refresh() {
        val t = qsTile ?: return
        t.label = "AI screen"
        t.state = if (BridgeService.instance?.screenOn == true) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.updateTile()
    }
}
