package com.aibubble

data class Platform(val name: String, val pkg: String, val keys: List<String>)

object Platforms {
    val all = listOf(
        Platform("Claude", "com.anthropic.claude", listOf("claude", "anthropic")),
        Platform("ChatGPT", "com.openai.chatgpt", listOf("openai", "chatgpt", "gpt")),
        Platform("Gemini", "com.google.android.apps.bard", listOf("gemini", "google", "bard")),
        Platform("Perplexity", "ai.perplexity.app.android", listOf("perplexity")),
        Platform("Copilot", "com.microsoft.copilot", listOf("copilot", "microsoft")),
        Platform("Grok", "ai.x.grok", listOf("grok", "xai"))
    )

    fun match(clientName: String): Platform? {
        val n = clientName.lowercase()
        return all.firstOrNull { p -> p.keys.any { n.contains(it) } }
    }
}
