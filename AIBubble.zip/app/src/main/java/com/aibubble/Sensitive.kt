package com.aibubble

import android.content.Context

// Opening any app whose package name contains one of these words ends a screen session.
object Sensitive {
    private val builtin = listOf(
        "bank", "chase", "wellsfargo", "capitalone", "citi", "usaa", "schwab", "fidelity",
        "paypal", "venmo", "cash", "zelle", "coinbase", "robinhood", "credit", "wallet",
        "bitwarden", "lastpass", "1password", "dashlane", "keepass", "authenticator"
    )

    fun matches(c: Context, pkg: String): Boolean {
        val n = pkg.lowercase()
        return builtin.any { n.contains(it) } || Config.extraBlock(c).any { n.contains(it) }
    }
}
